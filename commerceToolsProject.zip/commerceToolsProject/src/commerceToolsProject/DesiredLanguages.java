package commerceToolsProject;

import java.util.ArrayList;

public class DesiredLanguages {
	
	private Language java;
	private Language python;
	private Language node;
	private Language ruby;
	private Language scala;
	
	public DesiredLanguages() {
		java = new Language("java", "Java");
		python = new Language("python", "Python");
		node = new Language("node", "Node");
		ruby = new Language("ruby", "Ruby");
		scala = new Language("scala", "Scala");
	}
	
	public ArrayList<Language> getAllLanguages() {
		ArrayList<Language> listOfLanguages = new ArrayList<Language>();
		
		listOfLanguages.add(java);
		listOfLanguages.add(python);
		listOfLanguages.add(node);
		listOfLanguages.add(ruby);
		listOfLanguages.add(scala);
		
		return listOfLanguages;
	
	}
	
}
