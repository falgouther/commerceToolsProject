package commerceToolsProject;

import java.util.ArrayList;

public class DesiredJobLocations {  
	
	private Location BOSTON;
	private Location SAN_FRANCISCO;
	private Location LOS_ANGELES;
	private Location DENVER;
	private Location BOULDER;
	private Location CHICAGO;
	private Location NEW_YORK;	
	
	public DesiredJobLocations() {	
		BOSTON = new Location("boston", "Boston");
		SAN_FRANCISCO = new Location("san+francisco", "San Francisco");
		LOS_ANGELES = new Location("los+angeles", "Los Angeles");
		DENVER = new Location("denver", "Denver");
		BOULDER = new Location("boulder", "Boulder");
		CHICAGO = new Location("chicago", "Chicago");
		NEW_YORK = new Location("new+york", "New York");
	}
	
	public ArrayList<Location> getAllLocations() {
		ArrayList<Location> listOfLocations = new ArrayList<Location>();
		listOfLocations.add(BOSTON);
		listOfLocations.add(SAN_FRANCISCO);
		listOfLocations.add(LOS_ANGELES);
		listOfLocations.add(DENVER);
		listOfLocations.add(BOULDER);
		listOfLocations.add(CHICAGO);
		listOfLocations.add(NEW_YORK);
		
		return listOfLocations;
	}
}
