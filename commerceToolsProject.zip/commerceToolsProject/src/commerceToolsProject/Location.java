package commerceToolsProject;

import java.util.ArrayList;

public class Location {

	private String name;
	private double jobCount;
	private ArrayList<Language> desiredLanguages;
	
	public String displayName;
	
	public Location(String name, String displayName) {
		this.name = name;
		this.displayName = displayName;
		jobCount = 0;
		
		DesiredLanguages languages = new DesiredLanguages();
		desiredLanguages = languages.getAllLanguages();
	}
	
	public String getName() {
		return name;
	}
	
	public double getCount() {
		return jobCount;
	}
	
	public void increaseCountByOne() {
		jobCount++;
	}

	public void addLanguage(String languageName) {
		for (Language language : desiredLanguages) {
			if (language.getName().equals(languageName)) {
				language.increaseCountByOne();
				break;
			}
		} 
	}
	
	public ArrayList<Language> getAllDesiredLanguages() {
		return desiredLanguages;
	}
	
	public ArrayList<Language> getAllValidLanguages() {
		ArrayList<Language> validLanguages = new ArrayList<Language>();
		for (Language language : desiredLanguages) {
			if (language.getCount() > 0) {
				validLanguages.add(language);
			}
		}
		
		return validLanguages;
	}

}
