package commerceToolsProject;

public class Language {
	private String name;
	private double languageCount;
	
	public String displayName;
	
	public Language (String name, String displayName) {
		this.name = name;
		languageCount = 0;
		
		this.displayName = displayName;
	}

	public String getName() {
		return name;
	}
	
	public double getCount() {
		return languageCount;
	}
	
	public void increaseCountByOne() {
		languageCount++;
	}


}
