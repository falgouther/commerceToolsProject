/**
 * 
 */
package commerceToolsProject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * @author hannahfalgout
 *
 */
public class FindGitHubJobsCommand {
	//private HttpURLConnection httpConnection;
	
	final static String BASE_URL = "https://jobs.github.com/positions.json?";
	
	private ArrayList<Location> locationsList;
	private ArrayList<Language> languagesList;
	
	public FindGitHubJobsCommand() {
		DesiredJobLocations locations = new DesiredJobLocations();
		locationsList = locations.getAllLocations();
		
		languagesList = locationsList.get(0).getAllDesiredLanguages();
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FindGitHubJobsCommand jobs = new FindGitHubJobsCommand();
		jobs.availableFullTimePositions(BASE_URL);
		jobs.printValues();
	
	}
	
	private void availableFullTimePositions(String url) {
		for (Location city : locationsList) {
			for (Language language : languagesList) {
				String finalUrl = new StringBuilder()
						.append(url)
						.append("description=").append(language.getName())
						.append("&")
						.append("location=").append(city.getName())
						.append("&")
						.append("full_time=true")
						.toString();
				String responseToGet = sendGetRequest(finalUrl);
				if (responseToGet != null && !responseToGet.equals("[]")) {
					evaluateResponseString(responseToGet, city.getName(), language.getName(), false);
				}
			}
		}
	}
	
	public String sendGetRequest(String finalUrl) {
		//System.out.println(finalUrl);
		try {
			URL url = new URL(finalUrl);
			
			try {
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");
				BufferedReader in = new BufferedReader(
				        new InputStreamReader(connection.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				//print result
				System.out.println(response.toString());
				
				return response.toString();
			
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("URL connection failed to open");
			}

		} catch (MalformedURLException e) {
			e.printStackTrace();
			System.out.println("Failed to create URL");
		}
		
		return null;
	}
	
	private void evaluateResponseString(String response, String cityName, String languageName, boolean fullTime) {
		for (Location city : locationsList) {
			if (city.getName().equals(cityName)) {
				for (Language language: languagesList) {
					if (language.getName().equals(languageName)) {
						city.increaseCountByOne();
						city.addLanguage(language.getName());
						break;
					}
				}
			}
		}	
	}
	
	public void printValues(){
		double languagePercentage = 0;
		for (Location location : locationsList) {
			if (location.getCount() != 0) {
				System.out.println(location.displayName + " Jobs Available:" + location.getCount());
				for (Language language : location.getAllValidLanguages()) {
					if (location.getCount() > 0 && language.getCount() > 0) {
						languagePercentage = Math.round((language.getCount() / location.getCount()) * 100);
						System.out.println("            " + language.displayName + " makes up " + languagePercentage + "% of jobs available in this area.");
					}
				}
			}
		}
	}
}
